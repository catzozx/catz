<?php

Route::group(['middleware' => 'auth'], function () {
	Route::get('/logout','MainController@logout');

	Route::get('/dashboard','DashboardController@main');

	Route::get('/pelamar','PelamarController@main');
	Route::get('/pelamar/add','PelamarController@add');
	Route::post('/pelamar/add','PelamarController@addPost');

	Route::get('/kriteria','KriteriaController@main');
	Route::post('/kriteria','KriteriaController@hitungKriteria');

	Route::get('/listnilai','NilaiController@main');
	Route::get('/nilai/add','NilaiController@add');
	Route::post('/nilai/add','NilaiController@addPost');
	
});
Route::get('/','MainController@main');
Route::post('/','MainController@post');
