@extends('main_view')
@section('title','Pelamar Interview')
@section('title-content','Pelamar Interview')

@section('content')

<div class="row">
		<div class="col-md-12">
			@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
			<div class="card">
	            <form method="post">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Add</h4>
	                <div class="row">
	                	{{csrf_field()}}
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="pelamar"class="form-control">
	                            	<option value="">Pilih Pelamar</option>
	                            	@foreach ($pelamar as $o)
	                            	<option value="{{$o->id}}">{{$o->nama}} - {{$o->email}} - {{$o->jurusan}} - {{$o->tipe_pelamar}}</option>
	                            	@endforeach
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Jurusan
	                            </label>
	                            <input class="form-control" name="jurusan" type="number" maxlength="1" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Pengalaman
	                            </label>
	                            <input class="form-control" name="pengalaman" type="number" maxlength="1"/>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Psikotes
	                            </label>
	                            <input class="form-control" name="psikotes" type="number" maxlength="1"/>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Wawancara
	                            </label>
	                            <input class="form-control" name="wawancara" type="number" maxlength="1"/>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">Submit</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>

@endsection