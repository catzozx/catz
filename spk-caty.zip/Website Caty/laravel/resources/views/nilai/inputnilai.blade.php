@extends('main_view')
@section('title','List Nilai')
@section('title-content','List - Nilai')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <button type="button" rel="tooltip" class="btn btn-primary">
                            <i class="material-icons">add_circle</i><a style="color: white;font-weight: bold;" href="{{url('nilai/add')}}"> Tambah Input</a>
                    </button>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Jurusan</th>
                                <th class="text-center">Pengalaman</th>
                                <th class="text-center">Psikotes</th>
                                <th class="text-center">Wawancara</th>
                            </thead>
                            <tbody>
                                @foreach($pelamar as $o)
                                <tr class="text-center">
                                    <td><a href="{{url('listnilai')}}">
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">visibility</i>
                                        </button>
                                        </a></td>
                                    <td>{{$o->email}}</td>
                                    <td>{{$o->nama}}</td>
                                    <td>{{$o->jurusan}}</td>
                                    <td>{{$o->pengalaman}}</td>
                                    <td>{{$o->psikotes}}</td>
                                    <td>{{$o->wawancara}}</td>
                                </tr>
                                @endforeach
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

@endsection