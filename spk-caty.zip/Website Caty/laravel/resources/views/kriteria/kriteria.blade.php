@extends('main_view')
@section('title','List Kriteria')
@section('title-content','List - Kriteria')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <div class="table-responsive">
                        <form method="post">
                            {{csrf_field()}}
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Kode Kriteria</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Nilai</th>
                            </thead>
                            <tbody>
                                @foreach ($kriteria as $o)
                                <tr class="td-actions text-center">
                                    <td width="200">{{$o->kd_kriteria}}</td>
                                    <td>{{$o->nama_kriteria}}</td>
                                    <td>{{$o->nilai_kriteria}}</td>
                                </tr>
                                @endforeach
                            </tbody>

                        </table>
                        <button type="submit" class="btn btn-primary">Hitung nilai</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php 
        if (request()->has('jurusan')) {
            
         ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Hasil Perhitungan</h4>
                    <div class="table-responsive">
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
@endsection

@section('js')

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

@endsection