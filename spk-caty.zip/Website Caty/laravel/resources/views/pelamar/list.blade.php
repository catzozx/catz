@extends('main_view')
@section('title','List Pelamar')
@section('title-content','List - Pelamar')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <button type="button" rel="tooltip" class="btn btn-primary">
                            <i class="material-icons">add_circle</i><a style="color: white;font-weight: bold;" href="{{url('pelamar/add')}}"> Tambah Pelamar</a>
                    </button>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">No Telepon</th>
                                <th class="text-center">Alamat</th>
                                <th class="text-center">Tanggal Lahir</th>
                                <th class="text-center">Umur</th>
                                <th class="text-center">Jenis Kelamin</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Pendidikan Terakhir</th>
                                <th class="text-center">Jurusan</th>
                                <th class="text-center">Tipe Pelamar</th>
                                <th class="text-center">Tanggal di Insert</th>
                            </thead>
                            <tbody>
                            
                                @foreach ($pelamar as $o)
                                <tr class="td-actions text-center">
                                    <td><a href="{{url('detailproduct')}}{{'/'.$o->id}}">
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">visibility</i>
                                        </button>
                                        </a>
                                        <!-- <a data-confirm="Apakah Anda yakin ingin menghapus produk?" href="{{url('deleteproduct')}}{{'/'.$o->id}}">
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">delete_forever</i>
                                        </button>
                                        </a> -->
                                    </td>
                                    <td><?php $no = 0; $no++; echo $no; ?></td>
                                    <td>{{$o->nama}}</td>
                                    <td>{{$o->email}}</td>
                                    <td>{{$o->no_telp}}</td>
                                    <td>{{$o->alamat}}</td>
                                    <td>{{$o->tanggal_lahir}}</td>
                                    <td>{{$o->umur}}</td>
                                    <td>{{$o->jenis_kelamin}}</td>
                                    <td>{{$o->status}}</td>
                                    <td>{{$o->pend_terakhir}}</td>
                                    <td>{{$o->jurusan}}</td>
                                    <td>{{$o->tipe_pelamar}}</td>
                                    <td>{{$o->insert_at}}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

@endsection