@extends('main_view')
@section('title','Dashboard')
@section('title-content','Dashboard Information')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Infomation</h4>
                   
                </div>
            </div>
        </div>
    </div>
</div>
@endsection