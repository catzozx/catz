<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pelamar extends Model
{
    protected $table = "cty_pelamar";
    public $timestamps = false;
    protected $hidden = ['created_at','updated_at'];
    public $rules = [
        	'nama'=>'required',
        	'email'=>'required|email',
            'telp'=>'required',
            'tgl_lahir'=>'required',
            'alamat'=>'required',
            'jeniskelamin'=>'required',
            'status'=>'required',
            'pendterakhir'=>'required',
            'jurusan'=>'required',
            'tipe_pelamar'=>'required'
        ];
    public $rules_update = [
            'image'=>'max:2048|mimes:jpeg,png',
            'name'=>'required',
            'resolution'=>'required',
            'wifi'=>'required',
            'type'=>'required',
            'stock'=>'required|numeric',
            'price_12'=>'required|numeric',
            'price_24'=>'required|numeric'
        ];

    public $rulesID = ['id'=>'required|digits_between:1,5'];
}