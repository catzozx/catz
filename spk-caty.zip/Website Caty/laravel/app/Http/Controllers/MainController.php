<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class MainController extends Controller
{
    public function main(Request $request)
    {
    	if (Auth::id() > 0) {
    		return redirect('dashboard');
    	}
    	return view('login');
    }

    public function post(Request $request)
    {
        if ($request->input('email') == 'cty@gmail.com') {
            $credentials = $request->only('email', 'password');

            if (Auth::attempt($credentials)) {
                Session::flash('msg','Selamat, login Anda telah berhasil');
                Session::flash('type','success');
                return redirect('dashboard');
            }
            Session::flash('msg','Login gagal, Username/Password salah');
            Session::flash('type','danger');
            return redirect('');
        }else{
            Session::flash('msg','Akun Anda belum terdaftar sebagai Admin Dashboard');
            Session::flash('type','danger');
            return redirect('');
        }
    	
    }

    public function logout(Request $request)
    {
    	Session::flash('msg','Selamat, Anda telah berhasil logout');
    	Session::flash('type','success');
    	Auth::logout();
    	return redirect('');
    }
}
