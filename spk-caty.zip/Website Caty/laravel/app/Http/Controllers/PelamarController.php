<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Pelamar;

class PelamarController extends Controller
{
    public function main(Request $request)
    {
        $pelamar = DB::select("SELECT * FROM cty_pelamar");
        return view('pelamar.list')->with('pelamar',$pelamar);
    }

    public function add(Request $request)
    {
        return view('pelamar.add');
    }

    public function addPost(Request $request)
    {
        $pelamar = new Pelamar;
        $validasi = Validator::make($request->all(),$pelamar->rules);
        if ($validasi->fails()) {
            return redirect()->back()->withErrors($validasi);
        }

        // $exp_tgl_lahir = explode('/', $request->input('tgl_lahir'));
        // $umur = date('Y') - end($exp_tgl_lahir);

        $pelamar->nama = $request->input('nama');
        $pelamar->alamat = $request->input('alamat');
        $pelamar->email = $request->input('email');
        $pelamar->no_telp = $request->input('telp');
        $pelamar->tanggal_lahir = $request->input('tgl_lahir');
        $pelamar->jenis_kelamin = $request->input('jeniskelamin');
        $pelamar->umur = 22;
        $pelamar->pend_terakhir = $request->input('pendterakhir');
        $pelamar->jurusan = $request->input('jurusan');
        $pelamar->tipe_pelamar = $request->input('tipe_pelamar');
        $pelamar->status = $request->input('status');
        $pelamar->insert_at = date('Y-m-d H:i:s');
        $pelamar->save();
        


        Session::flash('msg','Data pelamar berhasil ditambah');
        Session::flash('type','success');
        return redirect('pelamar');
    }

    public function OnOrder(Request $request,$id)
    {
    	$order = DB::select("
                SELECT 
                    checkout.code_invoice,
                    user.email,
                    camera.resolution,
                    checkout.price,
                    checkout.quantity,
                    checkout.duration,
                    checkout.tgl_ambil,
                    camera.name name_camera
                    FROM rdp_user_checkout checkout
                LEFT JOIN rdp_user user ON checkout.userid = user.id
                LEFT JOIN rdp_camera camera ON checkout.camera_id = camera.id
                WHERE checkout.code_invoice = '".$id."' AND status_order = 0
                        ");
        return view('detailonorder')->with('order',$order);
    }

    public function OnOrderPost(Request $request,$id)
    {
        $validasi = Validator::make($request->all(),['dp'=>'required|numeric','verifikasi'=>'required|numeric','date'=>'required']);
        if ($validasi->fails()) {
            return redirect()->back()->withErrors($validasi);
        }
        DB::table('rdp_user_checkout')
            ->where('code_invoice', $id)
            ->update(['status_order' => 2,'updated_at'=>date('Y-m-d H:i:s')]);
        $total = DB::select("SELECT sum(price)total FROM rdp_user_checkout WHERE code_invoice = '".$id."'");
        $userid = DB::select("SELECT userid FROM rdp_user_checkout WHERE code_invoice = '".$id."'");
        DB::table('rdp_user_invoice')->insert([
            ['code_invoice' => $id,'dp'=>$request->input('dp'),'userid'=>$userid[0]->userid,'tgl_pengembalian'=>$request->input('date'),'total'=> $total[0]->total,'status_order' => 2,'updated_at'=>date('Y-m-d H:i:s')]
        ]);
        Session::flash('msg','Berhasil, Order telah diverifikasi');
        Session::flash('type','success');
        return redirect('listorder');
    }

    public function progress(Request $request)
    {
        $order = DB::select("SELECT inv.*,user.email,(inv.total - inv.dp)bayar FROM rdp_user_invoice inv
                LEFT JOIN (SELECT id,email FROM rdp_user)user ON inv.userid = user.id
                WHERE status_order = 2");
        return view('progress')->with('order',$order);
    }

    public function progressPost(Request $request,$id)
    {
        $order = DB::select("SELECT code_invoice FROM rdp_user_invoice WHERE status_order = 2");
        if ($order) {
            $c = DB::select("SELECT sum(quantity)quantity,camera_id FROM rdp_user_checkout WHERE code_invoice = '".$id."' GROUP BY camera_id");
            for ($i=0; $i <count($c); $i++) { 
                DB::table('rdp_camera')->where('id',$c[$i]->camera_id)->increment('stock', $c[$i]->quantity);
            }
            DB::table('rdp_user_checkout')
            ->where('code_invoice', $id)
            ->update(['status_order' => 1,'updated_at'=>date('Y-m-d H:i:s')]);
            DB::table('rdp_user_invoice')
            ->where('code_invoice', $id)
            ->update(['status_order' => 1,'updated_at'=>date('Y-m-d H:i:s')]);

            Session::flash('msg','Berhasil, Order telah Lunas');
            Session::flash('type','success');
            return redirect()->back();
        }else{
            Session::flash('msg','Gagal, Order tidak ditemukan');
            Session::flash('danger','success');
            return redirect()->back();
        }
        
    }

    public function confirm(Request $request)
    {
        $order = DB::select("SELECT inv.*,user.email FROM rdp_user_invoice inv
                LEFT JOIN (SELECT id,email FROM rdp_user)user ON inv.userid = user.id
                WHERE status_order = 1");
        $total = DB::select("SELECT sum(total)jumlah FROM rdp_user_invoice
                WHERE status_order = 1");
        return view('confirm')->with('order',$order)->with('total',$total);
    }
}
