<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Pelamar;

class KriteriaController extends Controller
{
    public function main(Request $request)
    {
        $kriteria = DB::select("SELECT * FROM cty_kriteria");
    	return view('kriteria.kriteria')->with('kriteria',$kriteria);
    }

    public function hitungKriteria(Request $request)
    {
        $jurusan = $request->input('jurusan');
        $pengalaman = $request->input('pengalaman');
        $psikotes = $request->input('psikotes');
        $wawancara = $request->input('wawancara');
        
        return redirect()->back();
    }

    

    public function post(Request $request)
    {
        if ($request->input('email') == 'cty@gmail.com') {
            $credentials = $request->only('email', 'password');

            if (Auth::attempt($credentials)) {
                Session::flash('msg','Selamat, login Anda telah berhasil');
                Session::flash('type','success');
                return redirect('dashboard');
            }
            Session::flash('msg','Login gagal, Username/Password salah');
            Session::flash('type','danger');
            return redirect('');
        }else{
            Session::flash('msg','Akun Anda belum terdaftar sebagai Admin Dashboard');
            Session::flash('type','danger');
            return redirect('');
        }
    	
    }

    
}
