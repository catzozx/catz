<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Pelamar;

class NilaiController extends Controller
{
    public function main(Request $request)
    {
    	$pelamar = DB::select("
    		SELECT 
    			 user.id,
    			 user.nama,
    			 user.email,
    			 pelamar.jurusan,
    			 pelamar.pengalaman,
    			 pelamar.psikotes,
    			 pelamar.wawancara
    		FROM cty_nilai_pelamar pelamar

    		LEFT JOIN
    		(
    			SELECT * FROM cty_pelamar
    		)user ON pelamar.id_pelamar = user.id
    		");
    	return view('nilai.inputnilai')->with('pelamar',$pelamar);
    }

    public function add(Request $request)
    {
        $pelamar = DB::select("SELECT * FROM cty_pelamar");
        return view('nilai.addnilai')->with('pelamar',$pelamar);
    }

    public function addPost(Request $request)
    {
    	if ($request->input('pelamar') != "" && $request->input('jurusan') != "" && $request->input('wawancara') != "" && $request->input('psikotes') != "") {
    		
    		DB::table('cty_nilai_pelamar')->insert([
		    [	'id_pelamar' => $request->input('pelamar'), 
		    	'jurusan' => $request->input('jurusan'),
		    	'psikotes'=>$request->input('psikotes'),
		    	'wawancara'=>$request->input('wawancara'),
		    	'pengalaman'=>$request->input('pengalaman')
		    ]
			]);
			Session::flash('msg','Data Interview Pelamar berhasil ditambah');
	        Session::flash('type','success');
	        return redirect('nilai/add'); 
    	}else{
    		Session::flash('msg','Harap isi form dengan benar');
	        Session::flash('type','danger');
	        return redirect('nilai/add'); 
    	}
    	
         
    }
}
