<?php $__env->startSection('title','List Pelamar'); ?>
<?php $__env->startSection('title-content','List - Pelamar'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <button type="button" rel="tooltip" class="btn btn-primary">
                            <i class="material-icons">add_circle</i><a style="color: white;font-weight: bold;" href="<?php echo e(url('pelamar/add')); ?>"> Tambah Pelamar</a>
                    </button>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">No Telepon</th>
                                <th class="text-center">Alamat</th>
                                <th class="text-center">Tanggal Lahir</th>
                                <th class="text-center">Umur</th>
                                <th class="text-center">Jenis Kelamin</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Pendidikan Terakhir</th>
                                <th class="text-center">Jurusan</th>
                                <th class="text-center">Tipe Pelamar</th>
                                <th class="text-center">Tanggal di Insert</th>
                            </thead>
                            <tbody>
                            
                                <?php $__currentLoopData = $pelamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td><a href="<?php echo e(url('detailproduct')); ?><?php echo e('/'.$o->id); ?>">
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">visibility</i>
                                        </button>
                                        </a>
                                        <!-- <a data-confirm="Apakah Anda yakin ingin menghapus produk?" href="<?php echo e(url('deleteproduct')); ?><?php echo e('/'.$o->id); ?>">
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">delete_forever</i>
                                        </button>
                                        </a> -->
                                    </td>
                                    <td><?php $no = 0; $no++; echo $no; ?></td>
                                    <td><?php echo e($o->nama); ?></td>
                                    <td><?php echo e($o->email); ?></td>
                                    <td><?php echo e($o->no_telp); ?></td>
                                    <td><?php echo e($o->alamat); ?></td>
                                    <td><?php echo e($o->tanggal_lahir); ?></td>
                                    <td><?php echo e($o->umur); ?></td>
                                    <td><?php echo e($o->jenis_kelamin); ?></td>
                                    <td><?php echo e($o->status); ?></td>
                                    <td><?php echo e($o->pend_terakhir); ?></td>
                                    <td><?php echo e($o->jurusan); ?></td>
                                    <td><?php echo e($o->tipe_pelamar); ?></td>
                                    <td><?php echo e($o->insert_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/caty.kerja.tech/public_html/laravel/resources/views/pelamar/list.blade.php ENDPATH**/ ?>