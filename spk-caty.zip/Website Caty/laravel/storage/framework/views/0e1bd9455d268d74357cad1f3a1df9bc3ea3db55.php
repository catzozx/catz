<?php $__env->startSection('title','Venue'); ?>
<?php $__env->startSection('title-content','Venue'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">search</i>
                </div>
                <form method="get">
                    <div class="card-content">
                    <h4 class="card-title">Filter Data</h4>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group label-floating">
                                    <label class="control-label">
                                        Name
                                    </label>
                                    <input class="form-control" name="name" type="text" value="" />
                                </div>
                            </div>    
                        </div>
                        <div class="form-footer text-right">
                            <a href="<?php echo e(url('venue/add')); ?>"><button type="button" class="btn btn-rose btn-fill">Add Venue</button></a>
                            <button type="submit" class="btn btn-rose btn-fill">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List Venue</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">ID</th>
                                <th class="text-center">ID Wilayah</th>
                                <th class="text-center">Venue Name</th>
                                <th class="text-center">Image Venue</th>
                                <th class="text-center">Price</th>
                                <th class="text-center">Province</th>
                                <th class="text-center">City</th>
                                <th class="text-center">Village</th>
                                <th class="text-center">Latitude</th>
                                <th class="text-center">Longitude</th>
                                <th class="text-center">Open</th>
                                <th class="text-center">Close</th>
                                <th class="text-center">Rating</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $venue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td><a href="<?php echo e(url('venue')); ?><?php echo e('/'.$v->id); ?>">
                <button type="button" rel="tooltip" class="btn btn-success">
                        <i class="material-icons">visibility</i>
                </button>
                </a>
                                    </td>
                                    <td><?php echo e($v->id); ?></td>
                                    <td><?php echo e($v->id_wilayah); ?></td>
                                    <td><?php echo e($v->nama); ?></td>
                                    <td><img class="img-custom" src="<?php echo e($v->img); ?>"></td>
                                    <td><?php echo e($v->harga); ?></td>
                                    <td><?php echo e($v->provinsi); ?></td>
                                    <td><?php echo e($v->kota); ?></td>
                                    <td><?php echo e($v->kecamatan); ?></td>
                                    <td><?php echo e($v->latitude); ?></td>
                                    <td><?php echo e($v->longitude); ?></td>
                                    <td><?php echo e($v->open_at); ?></td>
                                    <td><?php echo e($v->close_at); ?></td>
                                    <td><?php echo e($v->rating); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard_sparing/laravel/resources/views/venue/venue.blade.php ENDPATH**/ ?>