<?php $__env->startSection('title','Venue Detail'); ?>
<?php $__env->startSection('title-content','Venue Detail'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">search</i>
	             </div>
	             <div class="card-content">
		            <h4 class="card-title">Search for Get ID Wilayah</h4>
		            <div class="col-md-12">
		            	<div class="form-group label-floating">
                            <label class="control-label">
                                Search with CodePost, Example: 17111
                            </label>
                            <input class="form-control" id="kdpos" type="number"/>
	                    </div>
		            </div>
		        </div>
		        <div class="card-footer text-center">
	                <button id="getIDWilayah" type="button" class="btn btn-rose btn-fill">SUBMIT</button>
	            </div>	
			</div>	
		</div>		
	</div>
<div class="row">
		<div class="col-md-12">
			<div class="card">
	            <form method="post">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Edit</h4>
	                <div class="row">
	                	<?php echo e(csrf_field()); ?>

	                    <div class="col-md-4">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                ID Wilayah, Example: 1234
	                            </label>
	                            <input class="form-control" name="id_wilayah" type="text" value="<?php echo e($data['id_wilayah']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-4">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Name of Venue, Example: Bintang Sport Center
	                            </label>
	                            <input class="form-control" name="nama" type="text" value="<?php echo e($data['name']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-4">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Price of Venue, Example: 100000 
	                            </label>
	                            <input class="form-control" name="harga" type="number" min="0" minLength="5" value="<?php echo e($data['price']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Address, Example: String
	                            </label>
  								<textarea name="alamat" class="form-control" rows="5"><?php echo e($data['address']); ?></textarea>
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Description Venue, Example: String
	                            </label>
  								<textarea name="desc" class="form-control" rows="5"><?php echo e($data['description']); ?></textarea>
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Latitude, Example: -6.202085
	                            </label>
	                            <input class="form-control" name="latitude" type="text" value="<?php echo e($data['latitude']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Longitude, Example: 106.884392
	                            </label>
	                            <input class="form-control" name="longitude" type="text" value="<?php echo e($data['longitude']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Open Venue, Example : 09.00
	                            </label>
	                            <input class="form-control" name="open_at" type="text" value="<?php echo e($data['open_at']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Close Venue, Example: 23.00
	                            </label>
	                            <input class="form-control" name="close_at" type="text" value="<?php echo e($data['close_at']); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="form-group">
	                            <select name="provinsi" id="provinsi" class="form-control">
	                            	<option value="">-- Choose Province -- </option>
	                            	<option selected="selected" value="<?php echo e($data['provinsi']); ?>"><?php echo e($data['provinsi']); ?></option>
	                            	<?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<option value="<?php echo e($pro->provinsi); ?>"><?php echo e($pro->provinsi); ?></option>
	                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            	
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="form-group">
	                            <select name="kota" id="kota" class="form-control">
	                            	<option value="">-- Choose Kota -- </option>
	                            	<option selected="selected" value="<?php echo e($data['city']); ?>"><?php echo e($data['city']); ?></option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="form-group">
	                            <select name="kecamatan" id="kecamatan" class="form-control">
	                            	<option value="">-- Choose Village -- </option>
	                            	<option selected="selected" value="<?php echo e($data['kecamatan']); ?>"><?php echo e($data['kecamatan']); ?></option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="id_sport_category[]" id="id_sport_category" class="form-control" multiple="multiple">
	                            	<option value="">Choose Sport Category on the Venue</option>
	                            	<?php $__currentLoopData = $data['sport']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<option selected="selected" value="<?php echo e($sprt->id); ?>"><?php echo e($sprt->nama); ?></option>	
	                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nama); ?></option>	
	                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            
								</select>
	                        </div>
	                    </div>
	                    <?php $no = 0; ?>
	                    <?php $__currentLoopData = $data['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <?php $no++; ?>
	                    <div class="col-md-4">
	                    	<div style="padding-top: 10px;padding-bottom: 10px; margin-top: 10px;" class="text-center">
	                    		<img style="width: 150px;height: 75px;" src="<?php echo e($image->img); ?>">
	                    		<h5>Image ke <?php echo $no; ?></h5>
	                    		<div>
	                    			<label class="control-label">Update Image</label>
	                    			<input class="form-control-file" type="file" name="img[]">
	                    			<button type="button" class="btn btn-danger btn-fill">Delete</button>
	                    		</div>	
	                    	</div>
	                    	
	                    </div>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">Update data Venue</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>
	<div class="modal fade" id="modal1">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">ID Wilayah Information</h5>
      </div>
      <div class="modal-body">
       	<h2 id="modalbody" class="text-bold text-center"></h2>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-rose btn-fill" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$('#provinsi').select2({
	  placeholder: 'Select a Province'
	});
	$('#kota').select2({
	  placeholder: 'Select a City',

	});
	$('#kecamatan').select2({
	  placeholder: 'Select a Village'
	});
	$('#id_sport_category').select2({
	  placeholder: 'Choose Sport Category on the Venue'
	});

	$('#provinsi').change(function() {
		    getKota(this.value);
		    $('#kecamatan').empty();
	});
	$('#kota').change(function() {
		    getKecamatan(this.value);
	});


	function getKota(provinsi){
	   $(function () {
	      $.ajax({
	        url   : "https://sparing.kerja.tech/kota",
	        data  : {"provinsi":provinsi},
	        headers : {
	        	Accept:'mbyhosmfcmkygftmtwkrgiletjhcjfnx'
	        },
	        type : "POST",
	        dataType: 'json',
	        success : function(json){
		          $('#kota').empty();
		          for (var i = 0; i < json.data.list.length; i++) {
		          	var item = json.data.list[i]
		          	$("#kota").append('<option value="'+item.kabkota+'">'+item.kabkota+'</option>');
		          }
		          $('#kota').val("")
	        	}
			});
		}); 
	}
	function getKecamatan(kota){
	   $(function () {
	      $.ajax({
	        url   : "https://sparing.kerja.tech/kecamatan",
	        data  : {"kota":kota},
	        headers : {
	        	Accept:'mbyhosmfcmkygftmtwkrgiletjhcjfnx'
	        },
	        type : "POST",
	        dataType: 'json',
	        success : function(json){
		          $('#kecamatan').empty();
		          for (var i = 0; i < json.data.list.length; i++) {
		          	var item = json.data.list[i]
		          	$("#kecamatan").append('<option value="'+item.kecamatan+'">'+item.kecamatan+'</option>');
		          }
		          $('#kecamatan').val("")
	        	}
			});
		}); 
	}

	$('#getIDWilayah').click(function(argument){
		var input = $('#kdpos').val()
		if (input.length != 5) {
			$('#modalbody').html("Kode Pos harus 5 digit");
			$('#modal1').modal('show');
			return false;
		}
		$.ajax({
	        url   : "https://sparing.kerja.tech/infolokasi",
	        data  : {"kdpos":input},
	        headers : {
	        	Accept:'mbyhosmfcmkygftmtwkrgiletjhcjfnx'
	        },
	        type : "POST",
	        dataType: 'json',
	        success : function(json){
	        	if (json.success == false) {
	        		$('#modalbody').html("ID Wilayah dengan Kode Pos tersebut tidak ditemukan");
	        		$('#modal1').modal('show');
	        		return false	
	        	}
		 		$('#modalbody').html(json.data.id);
		 		$('#modal1').modal('show');
		 		return true	      
	        }
		});
	});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/dashboardsparing.kerja.tech/public_html/laravel/resources/views/venue/detail.blade.php ENDPATH**/ ?>