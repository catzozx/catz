<?php $__env->startSection('title','Verification'); ?>
<?php $__env->startSection('title-content','User Verification - Pending'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">Email</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td><a href="<?php echo e(url('detailverification')); ?><?php echo e('/'.$u->id); ?>">
                <button type="button" rel="tooltip" class="btn btn-success">
                        <i class="material-icons">visibility</i>
                </button>
                </a>
                                    </td>
                                    <td><?php echo e($u->email); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/rdpdashboard.kerja.tech/public_html/laravel/resources/views/listverification.blade.php ENDPATH**/ ?>