<?php $__env->startSection('title','Pelamar Add'); ?>
<?php $__env->startSection('title-content','Pelamar Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
		<div class="col-md-12">
			<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
			<div class="card">
	            <form method="post">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Add</h4>
	                <div class="row">
	                	<?php echo e(csrf_field()); ?>

	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Nama
	                            </label>
	                            <input class="form-control" name="nama" type="text" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Email
	                            </label>
	                            <input class="form-control" name="email" type="email" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Nomor Telepon
	                            </label>
	                            <input class="form-control" name="telp" type="text" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label>
	                                Tanggal Lahir
	                            </label>
	                            <input class="form-control" name="tgl_lahir" type="date" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label>
	                                Alamat
	                            </label>
	                            <input class="form-control" name="alamat" type="textarea" />
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="jeniskelamin"class="form-control">
	                            	<option value="">Pilih Jenis Kelamin</option>
	                            	<option value="Pria">Pria</option>
	                            	<option value="Wanita">Wanita</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="status"class="form-control">
	                            	<option value="">Pilih Status</option>
	                            	<option value="Menikah">Menikah</option>
	                            	<option value="Belum Menikah">Belum Menikah</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="pendterakhir"class="form-control">
	                            	<option value="">Pilih Pendidikan</option>
	                            	<option value="S2">S2</option>
	                            	<option value="S1">S1</option>
	                            	<option value="D3">D3</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group">
	                            <select name="jurusan"class="form-control">
	                            	<option value="">Pilih Jurusan</option>
	                            	<option value="Psikolog">Psikolog</option>
	                            	<option value="Hukum">Hukum</option>
	                            	<option value="Manajemen">Manajemen</option>
	                            	<option value="Dll">Dan lain-lain</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group">
	                            <select name="tipe_pelamar"class="form-control">
	                            	<option value="">Pilih Tipe Pelamar</option>
	                            	<option value="Berpengalaman">Berpengalaman</option>
	                            	<option value="Tidak Berpengalaman">Tidak Berpengalaman</option>
								</select>
	                        </div>
	                    </div>
	                    
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">Tambah Pelamar</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/caty.kerja.tech/public_html/laravel/resources/views/pelamar/add.blade.php ENDPATH**/ ?>