<?php $__env->startSection('title','Pelamar Interview'); ?>
<?php $__env->startSection('title-content','Pelamar Interview'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
		<div class="col-md-12">
			<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
			<div class="card">
	            <form method="post">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Add</h4>
	                <div class="row">
	                	<?php echo e(csrf_field()); ?>

	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="pelamar"class="form-control">
	                            	<option value="">Pilih Pelamar</option>
	                            	<?php $__currentLoopData = $pelamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<option value="<?php echo e($o->id); ?>"><?php echo e($o->nama); ?> - <?php echo e($o->email); ?> - <?php echo e($o->jurusan); ?> - <?php echo e($o->tipe_pelamar); ?></option>
	                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Jurusan
	                            </label>
	                            <input class="form-control" name="jurusan" type="number" maxlength="1" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Pengalaman
	                            </label>
	                            <input class="form-control" name="pengalaman" type="number" maxlength="1"/>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Psikotes
	                            </label>
	                            <input class="form-control" name="psikotes" type="number" maxlength="1"/>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Wawancara
	                            </label>
	                            <input class="form-control" name="wawancara" type="number" maxlength="1"/>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">Submit</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/caty.kerja.tech/public_html/laravel/resources/views/nilai/addnilai.blade.php ENDPATH**/ ?>