<?php $__env->startSection('title','List Product'); ?>
<?php $__env->startSection('title-content','List - Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <button type="button" rel="tooltip" class="btn btn-primary">
                            <i class="material-icons">add_circle</i><a style="color: white;font-weight: bold;" href="<?php echo e(url('addproduct')); ?>"> Tambah Produk</a>
                    </button>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">Image</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">Type</th>
                                <th class="text-center">Resolution</th>
                                <th class="text-center">Wifi Support</th>
                                <th class="text-center">Stock</th>
                                <th class="text-center">Price 12 Jam</th>
                                <th class="text-center">Price 24 Jam</th>
                            </thead>
                            <tbody>
                            
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td><a href="<?php echo e(url('detailproduct')); ?><?php echo e('/'.$o->id); ?>">
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">visibility</i>
                                        </button>
                                        </a>
                                        <a data-confirm="Apakah Anda yakin ingin menghapus produk?" href="<?php echo e(url('deleteproduct')); ?><?php echo e('/'.$o->id); ?>">
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">delete_forever</i>
                                        </button>
                                        </a>
                                    </td>
                                    <td><img style="max-width: 120px;min-height: 100px;" src="<?php echo e($o->img); ?>"></td>
                                    <td><?php echo e($o->name); ?></td>
                                    <td><?php echo e($o->type); ?></td>
                                    <td><?php echo e($o->resolution); ?></td>
                                    <td><?php echo e($o->wifi); ?></td>
                                    <td><?php echo e($o->stock); ?></td>
                                    <td><?php echo e($o->price_12); ?></td>
                                    <td><?php echo e($o->price_24); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/rdpdashboard.kerja.tech/public_html/laravel/resources/views/list_produk.blade.php ENDPATH**/ ?>