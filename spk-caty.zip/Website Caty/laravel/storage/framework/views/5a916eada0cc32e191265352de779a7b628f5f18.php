<?php $__env->startSection('title','Product Add'); ?>
<?php $__env->startSection('title-content','Add Produk'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
		<div class="col-md-12">
			<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
			<div class="card">
	            <form method="post" enctype="multipart/form-data">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Add</h4>
	                <div class="row">
	                	<?php echo e(csrf_field()); ?>

	                	<div class="col-md-4">
                            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 250px;max-height: 250px;">
                                	
                                </div>
                                <div>
                                    <span class="btn btn-rose btn-round btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                       					<input type="file" name="image"/>
                                    </span>
                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                </div>
                            </div>
                        </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Name
	                            </label>
	                            <input class="form-control" name="name" type="text" />
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="wifi"class="form-control">
	                            	<option value="">Choose Support Wifi of Camera</option>
	                            	<option value="yes">Yes</option>
	                            	<option value="no">No</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="type"class="form-control">
	                            	<option value="">Choose Type of Camera</option>
	                            	<option value="SLR">SLR</option>
	                            	<option value="DSLR">DSLR</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Resolution
	                            </label>
	                            <input class="form-control" name="resolution" type="text" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Stock
	                            </label>
	                            <input class="form-control" name="stock" type="number" min="0" minLength="5" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Price 12 Jam
	                            </label>
	                            <input class="form-control" name="price_12" type="number" min="0" minLength="5" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Price 24 Jam
	                            </label>
	                            <input class="form-control" name="price_24" type="number" min="0" minLength="5"/>
	                        </div>
	                    </div>
	                    
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">Tambah Product</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/rdpdashboard.kerja.tech/public_html/laravel/resources/views/add_produk.blade.php ENDPATH**/ ?>