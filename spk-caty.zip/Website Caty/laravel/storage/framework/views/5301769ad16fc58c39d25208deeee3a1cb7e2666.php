<?php $__env->startSection('title','Rent Camera'); ?>
<?php $__env->startSection('title-content','Order - Pending'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">Invoice</th>
                            </thead>
                            <tbody>
                            
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td><a href="<?php echo e(url('onorder')); ?><?php echo e('/'.$o->code_invoice); ?>">
                <button type="button" rel="tooltip" class="btn btn-success">
                        <i class="material-icons">visibility</i>
                </button>
                </a>
                                    </td>
                                    <td><?php echo e($o->code_invoice); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/rdpdashboard.kerja.tech/public_html/laravel/resources/views/listorder.blade.php ENDPATH**/ ?>