<?php $__env->startSection('title','Product Detail'); ?>
<?php $__env->startSection('title-content','Product Detail'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
		<div class="col-md-12">
			<div class="card">
	            <form method="post" enctype="multipart/form-data">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Edit</h4>
	                <div class="row">
	                	<?php echo e(csrf_field()); ?>

	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Name
	                            </label>
	                            <input class="form-control" name="name" type="text" value="<?php echo e($data[0]->name); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="wifi"class="form-control">
	                            	<option value="">Choose Support Wifi of Camera</option>
	                            	<option value="yes"<?php if ($data[0]->wifi == 'yes') {echo "selected='selected'";} ?>>Yes</option>
	                            	<option value="no"<?php if ($data[0]->wifi == 'no') {echo "selected='selected'";} ?>>No</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="type"class="form-control">
	                            	<option value="">Choose Type of Camera</option>
	                            	<option value="SLR"<?php if ($data[0]->type == 'SLR') {echo "selected='selected'";} ?>>SLR</option>
	                            	<option value="DSLR"<?php if ($data[0]->type == 'DSLR') {echo "selected='selected'";} ?>>DSLR</option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Resolution
	                            </label>
	                            <input class="form-control" name="resolution" type="text" value="<?php echo e($data[0]->resolution); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Stock
	                            </label>
	                            <input class="form-control" name="harga" type="number" min="0" minLength="5" value="<?php echo e($data[0]->stock); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Price 12 Jam
	                            </label>
	                            <input class="form-control" name="stock" type="number" min="0" minLength="5" value="<?php echo e($data[0]->price_12); ?>" />
	                        </div>
	                    </div>
	                    <div class="col-md-12">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Price 24 Jam
	                            </label>
	                            <input class="form-control" name="stock" type="number" min="0" minLength="5" value="<?php echo e($data[0]->price_24); ?>" />
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">Update data Product</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/rdpdashboard.kerja.tech/public_html/laravel/resources/views/detail_produk.blade.php ENDPATH**/ ?>