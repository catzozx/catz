<?php $__env->startSection('title','Order Progress'); ?>
<?php $__env->startSection('title-content','Order - Progress'); ?>

<?php $__env->startSection('content'); ?>
<?php 
function rupiah($angka){
    
    $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
    return $hasil_rupiah;
 
}
 ?>

<div class="container-fluid">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Invoice</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">DP</th>
                                <th class="text-center">Total</th>
                                <th class="text-center">Total yang harus dibayar</th>
                                <th class="text-center">Tanggal Pengembalian</th>
                                <th class="text-center">Konfirmasi Pelunasan</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td><?php echo e($u->code_invoice); ?></td>
                                    <td><?php echo e($u->email); ?></td>
                                    <td><?php echo e(rupiah($u->dp)); ?></td>
                                    <td><?php echo e(rupiah($u->total)); ?></td>
                                    <td><?php echo e(rupiah($u->bayar)); ?></td>
                                    <td><?php echo e($u->tgl_pengembalian); ?></td>
                                    <td><a href="<?php echo url('orderprogress').'/'.$u->code_invoice; ?>">Lunas</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/rdpdashboard.kerja.tech/public_html/laravel/resources/views/progress.blade.php ENDPATH**/ ?>