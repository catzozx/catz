<?php $__env->startSection('title','List Kriteria'); ?>
<?php $__env->startSection('title-content','List - Kriteria'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <div class="table-responsive">
                        <form method="post">
                            <?php echo e(csrf_field()); ?>

                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Kode Kriteria</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Nilai</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="td-actions text-center">
                                    <td width="200"><?php echo e($o->kd_kriteria); ?></td>
                                    <td><?php echo e($o->nama_kriteria); ?></td>
                                    <td><?php echo e($o->nilai_kriteria); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                        <button type="submit" class="btn btn-primary">Hitung nilai</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php 
        if (request()->has('jurusan')) {
            
         ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Hasil Perhitungan</h4>
                    <div class="table-responsive">
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/caty.kerja.tech/public_html/laravel/resources/views/kriteria/kriteria.blade.php ENDPATH**/ ?>