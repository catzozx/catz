<?php $__env->startSection('title','Venue'); ?>
<?php $__env->startSection('title-content','Venue Add'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">search</i>
	             </div>
	             <div class="card-content">
		            <h4 class="card-title">Search for Get ID Wilayah</h4>
		            <div class="col-md-12">
		            	<div class="form-group label-floating">
                            <label class="control-label">
                                Search with CodePost, Example: 17111
                            </label>
                            <input class="form-control" id="kdpos" type="number"/>
	                    </div>
		            </div>
		        </div>
		        <div class="card-footer text-center">
	                <button id="getIDWilayah" type="button" class="btn btn-rose btn-fill">SUBMIT</button>
	            </div>	
			</div>	
		</div>		
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="card">
	            <form method="post">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">add_box</i>
                </div>
				<div class="card-content">
	            <h4 class="card-title">Add</h4>
	                <div class="row">
	                	<?php echo e(csrf_field()); ?>

	                    <div class="col-md-4">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                ID Wilayah, Example: 1234
	                            </label>
	                            <input class="form-control" name="id_wilayah" type="text" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-4">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Name of Venue, Example: Bintang Sport Center
	                            </label>
	                            <input class="form-control" name="nama" type="text" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-4">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Price of Venue, Example: 100000 
	                            </label>
	                            <input class="form-control" name="harga" type="number" min="0" minLength="5" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Address, Example: String
	                            </label>
  								<textarea name="alamat" class="form-control" rows="5"></textarea>
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Description Venue, Example: String
	                            </label>
  								<textarea name="desc" class="form-control" rows="5"></textarea>
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Latitude, Example: -6.202085
	                            </label>
	                            <input class="form-control" name="latitude" type="text" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Longitude, Example: 106.884392
	                            </label>
	                            <input class="form-control" name="longitude" type="text" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Open Venue, Example : 09.00
	                            </label>
	                            <input class="form-control" name="open_at" type="text" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-6">
	                        <div class="form-group label-floating">
	                            <label class="control-label">
	                                Close Venue, Example: 23.00
	                            </label>
	                            <input class="form-control" name="close_at" type="text" value="" />
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="form-group">
	                            <select name="provinsi" id="provinsi" class="form-control">
	                            	<option value="">-- Choose Province -- </option>
	                            	<?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<option value="<?php echo e($pro->provinsi); ?>"><?php echo e($pro->provinsi); ?></option>
	                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="form-group">
	                            <select name="kota" id="kota" class="form-control">
	                            	<option value="">-- Choose Kota -- </option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-4 text-center">
	                        <div class="form-group">
	                            <select name="kecamatan" id="kecamatan" class="form-control">
	                            	<option value="">-- Choose Village -- </option>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                        <div class="form-group">
	                            <select name="id_sport_category[]" id="id_sport_category" class="form-control" multiple="multiple">
	                            	<option value="">Choose Sport Category on the Venue</option>
	                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nama); ?></option>	
	                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
	                        </div>
	                    </div>
	                    <div class="col-md-12 text-center">
	                    	<legend>Image Venue</legend>
	                    </div>
	                    <div class="col-md-4">
                            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 250px;max-height: 250px;">
                                	
                                </div>
                                <div>
                                    <span class="btn btn-rose btn-round btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img[]" />
                                    </span>
                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 250px;max-height: 250px;">
                                	
                                </div>
                                <div>
                                    <span class="btn btn-rose btn-round btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img[]" />
                                    </span>
                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 250px;max-height: 250px;">
                                	
                                </div>
                                <div>
                                    <span class="btn btn-rose btn-round btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img[]" />
                                    </span>
                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 250px;max-height: 250px;">
                                	
                                </div>
                                <div>
                                    <span class="btn btn-rose btn-round btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img[]" />
                                    </span>
                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 250px;max-height: 250px;">
                                	
                                </div>
                                <div>
                                    <span class="btn btn-rose btn-round btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img[]" />
                                    </span>
                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                </div>
                            </div>
                        </div>
	                </div>
	            </div>
	            <div class="card-footer text-center">
	                <button type="submit" class="btn btn-rose btn-fill">SUBMIT</button>
	            </div>
	        </form>
	        </div>
		</div>
	</div>
</div>
<div class="modal fade" id="modal1">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">ID Wilayah Information</h5>
      </div>
      <div class="modal-body">
       	<h2 id="modalbody" class="text-bold text-center"></h2>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-rose btn-fill" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$('#provinsi').select2({
	  placeholder: 'Select a Province'
	});
	$('#kota').select2({
	  placeholder: 'Select a City',

	});
	$('#kecamatan').select2({
	  placeholder: 'Select a Village'
	});
	$('#id_sport_category').select2({
	  placeholder: 'Choose Sport Category on the Venue'
	});

	$('#provinsi').change(function() {
		    getKota(this.value);
		    $('#kecamatan').empty();
	});
	$('#kota').change(function() {
		    getKecamatan(this.value);
	});


	function getKota(provinsi){
	   $(function () {
	      $.ajax({
	        url   : "https://sparing.kerja.tech/kota",
	        data  : {"provinsi":provinsi},
	        headers : {
	        	Accept:'mbyhosmfcmkygftmtwkrgiletjhcjfnx'
	        },
	        type : "POST",
	        dataType: 'json',
	        success : function(json){
		          $('#kota').empty();
		          for (var i = 0; i < json.data.list.length; i++) {
		          	var item = json.data.list[i]
		          	$("#kota").append('<option value="'+item.kabkota+'">'+item.kabkota+'</option>');
		          }
		          $('#kota').val("")
	        	}
			});
		}); 
	}
	function getKecamatan(kota){
	   $(function () {
	      $.ajax({
	        url   : "https://sparing.kerja.tech/kecamatan",
	        data  : {"kota":kota},
	        headers : {
	        	Accept:'mbyhosmfcmkygftmtwkrgiletjhcjfnx'
	        },
	        type : "POST",
	        dataType: 'json',
	        success : function(json){
		          $('#kecamatan').empty();
		          for (var i = 0; i < json.data.list.length; i++) {
		          	var item = json.data.list[i]
		          	$("#kecamatan").append('<option value="'+item.kecamatan+'">'+item.kecamatan+'</option>');
		          }
		          $('#kecamatan').val("")
	        	}
			});
		}); 
	}

	$('#getIDWilayah').click(function(argument){
		var input = $('#kdpos').val()
		if (input.length != 5) {
			$('#modalbody').html("Kode Pos harus 5 digit");
			$('#modal1').modal('show');
			return false;
		}
		$.ajax({
	        url   : "https://sparing.kerja.tech/infolokasi",
	        data  : {"kdpos":input},
	        headers : {
	        	Accept:'mbyhosmfcmkygftmtwkrgiletjhcjfnx'
	        },
	        type : "POST",
	        dataType: 'json',
	        success : function(json){
	        	if (json.success == false) {
	        		$('#modalbody').html("ID Wilayah dengan Kode Pos tersebut tidak ditemukan");
	        		$('#modal1').modal('show');
	        		return false	
	        	}
		 		$('#modalbody').html(json.data.id);
		 		$('#modal1').modal('show');
		 		return true	      
	        }
		});
	});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/dashboardsparing.kerja.tech/public_html/laravel/resources/views/venue/add.blade.php ENDPATH**/ ?>