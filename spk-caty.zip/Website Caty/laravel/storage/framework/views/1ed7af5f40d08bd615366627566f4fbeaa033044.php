<?php $__env->startSection('title','List Nilai'); ?>
<?php $__env->startSection('title-content','List - Nilai'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">assignment</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">List</h4>
                    <button type="button" rel="tooltip" class="btn btn-primary">
                            <i class="material-icons">add_circle</i><a style="color: white;font-weight: bold;" href="<?php echo e(url('nilai/add')); ?>"> Tambah Input</a>
                    </button>
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th class="text-center">Action</th>
                                <th class="text-center">Email</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center">Jurusan</th>
                                <th class="text-center">Pengalaman</th>
                                <th class="text-center">Psikotes</th>
                                <th class="text-center">Wawancara</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pelamar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><a href="<?php echo e(url('listnilai')); ?>">
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">visibility</i>
                                        </button>
                                        </a></td>
                                    <td><?php echo e($o->email); ?></td>
                                    <td><?php echo e($o->nama); ?></td>
                                    <td><?php echo e($o->jurusan); ?></td>
                                    <td><?php echo e($o->pengalaman); ?></td>
                                    <td><?php echo e($o->psikotes); ?></td>
                                    <td><?php echo e($o->wawancara); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).on('click', ':not(form)[data-confirm]', function(e){
        if(!confirm($(this).data('confirm')))
        {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/caty.kerja.tech/public_html/laravel/resources/views/nilai/inputnilai.blade.php ENDPATH**/ ?>